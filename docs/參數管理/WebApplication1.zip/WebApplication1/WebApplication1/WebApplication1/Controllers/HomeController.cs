﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace WebApplication1
{
    public class HomeController : Controller
    {
        // Fields
        private readonly IConfiguration _configuration = null;


        // Constructors
        public HomeController(IConfiguration configuration)
        {
            // Default
            _configuration = configuration;
        }


        // Methods
        public ActionResult Index()
        {
            // ViewBag
            this.ViewBag.Message = _configuration.GetSection("WebApplication1:Message").Get<string>();

            // Return
            return View();
        }
    }
}
