﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1
{
    public class HomeController : Controller
    {
        // Fields
        private readonly MessageContext _messageContext = null;


        // Constructors
        public HomeController(MessageContext messageContext)
        {
            // Default
            _messageContext = messageContext;
        }


        // Methods
        public ActionResult Index()
        {
            // ViewBag
            this.ViewBag.Message = _messageContext.GetValue();

            // Return
            return View();
        }
    }
}
