﻿using MDP.Registration;

namespace WebApplication1
{
    [Service<MessageRepository>()]
    public class MockMessageRepository : MessageRepository
    {
        // Methods
        public string GetValue()
        {
            // Return
            return "Hello World By Mock Source";
        }
    }
}
