﻿using MDP.Registration;

namespace WebApplication1
{
    [Service<MessageRepository>()]
    public class SqlMessageRepository : MessageRepository
    {
        // Fields
        private readonly string _connectionString;


        // Constructors
        public SqlMessageRepository(string connectionString)
        {
            // Default
            _connectionString = connectionString;
        }


        // Methods
        public string GetValue()
        {
            // Return
            return "Hello World By " + _connectionString;
        }
    }
}
