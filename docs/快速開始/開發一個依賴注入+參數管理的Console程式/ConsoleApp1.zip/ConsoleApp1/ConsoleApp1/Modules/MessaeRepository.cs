﻿namespace ConsoleApp1
{
    public interface MessaeRepository
    {
        // Methods
        string GetValue();
    }
}
