﻿using MDP.Registration;

namespace ConsoleApp1
{
    [Service<MessaeRepository>()]
    public class ConfigMessaeRepository : MessaeRepository
    {
        // Fields
        private readonly string _message;


        // Constructors
        public ConfigMessaeRepository(string message)
        {
            // Default
            _message = message;
        }


        // Methods
        public string GetValue()
        {
            // Return
            return _message;
        }
    }
}
