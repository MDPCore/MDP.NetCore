﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1
{
    public class HomeController : Controller
    {
        // Fields
        private readonly MessaeRepository _messaeRepository = null;


        // Constructors
        public HomeController(MessaeRepository messaeRepository)
        {
            // Default
            _messaeRepository = messaeRepository;
        }


        // Methods
        public IndexResultModel Index()
        {
            // ResultModel
            var resultModel = new IndexResultModel();
            resultModel.Message = _messaeRepository.GetValue();

            // Return
            return resultModel;
        }


        // Class
        public class IndexResultModel
        {
            // Properties
            public string Message { get; set; }
        }
    }
}
