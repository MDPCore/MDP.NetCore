﻿using System;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1
{
    public class HomeController : Controller
    {
        // Fields
        private readonly MessaeRepository _messaeRepository = null;


        // Constructors
        public HomeController(MessaeRepository messaeRepository)
        {
            // Default
            _messaeRepository = messaeRepository;
        }


        // Methods
        public ActionResult Index()
        {
            // ViewBag
            this.ViewBag.Message = _messaeRepository.GetValue();

            // Return
            return View();
        }
    }
}
